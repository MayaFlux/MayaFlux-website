#include "day_2.hpp"

#include "MayaFlux/Buffers/Geometry/CompositeGeometryBuffer.hpp"

// =========================================================================
// A: Rhythm Machine
// =========================================================================
//
// Three voices built from first principles: no samples, no presets.
// Kick = low sine shaped by exponential decay.
// Snare = filtered noise shaped by fast decay.
// Hat = high sine shaped by very fast decay.
// Visuals: three columns of points whose height tracks energy.
// Space to start/stop. C to toggle hat chaos.

void day2_a_rhythm_machine()
{
    auto window = create_window({ .title = "Rhythm Machine",
        .width = 1920,
        .height = 1080 });

    struct State {
        bool sequencing { };
        bool chaos_mode { };
    };
    auto state = std::make_shared<State>();

    auto kick_phasor = vega.Phasor(20.0, 1.0);
    auto kick_env = vega.Polynomial([](double x) {
        return std::exp(-x * 15.0);
    });
    kick_env->set_input_node(kick_phasor);
    auto kick_tone = vega.Sine(55.0) | Audio[0];
    kick_tone->set_amplitude_modulator(kick_env);

    auto snare_phasor = vega.Phasor(30.0, 1.0);
    auto snare_env = vega.Polynomial([](double x) {
        return std::exp(-x * 25.0);
    }) | Audio[0];
    snare_env->set_input_node(snare_phasor);
    auto snare_noise = vega.Random();
    auto snare_filter = vega.FIR(snare_noise, std::vector { 0.3, 0.4, 0.3 });
    auto snare_shaped = snare_filter * snare_env;
    register_audio_node(snare_shaped, 1);

    auto hat_phasor = vega.Phasor(50.0, 1.0);
    auto hat_env = vega.Polynomial([](double x) {
        return std::exp(-x * 50.0);
    });
    hat_env->set_input_node(hat_phasor);
    auto hat_tone = vega.Sine(8000.0) | Audio[0];
    hat_tone->set_amplitude_modulator(hat_env);

    auto points = vega.PointCollectionNode(100) | Graphics;
    auto geom = vega.GeometryBuffer(points) | Graphics;
    geom->setup_rendering({ .target_window = window });
    window->show();

    schedule_metro(0.5, [kick_phasor, state]() {
        if (!state->sequencing) return;
        kick_phasor->reset(); }, "kick_layer");

    schedule_pattern(
        [](uint64_t step) { return (step % 4 == 2); },
        [snare_phasor, state](std::any hit) {
            if (!state->sequencing)
                return;
            if (std::any_cast<bool>(hit))
                snare_phasor->reset();
        },
        0.25, "snare_pattern");

    schedule_pattern(
        [state](uint64_t step) {
            if (state->chaos_mode)
                return get_uniform_random(0.0, 1.0) > 0.6;
            return true;
        },
        [hat_phasor, state](std::any hit) {
            if (!state->sequencing)
                return;
            if (std::any_cast<bool>(hit))
                hat_phasor->reset();
        },
        0.125, "hat_pattern");

    schedule_metro(0.016, [points, kick_tone, snare_shaped, hat_tone]() {
        points->clear_points();

        auto kick_e = std::abs(static_cast<float>(kick_tone->get_last_output())) * 3.0F;
        auto snare_e = std::abs(static_cast<float>(snare_shaped->get_last_output())) * 3.0F;
        auto hat_e = std::abs(static_cast<float>(hat_tone->get_last_output())) * 3.0F;

        for (int i = 0; i < 20; ++i) {
            float y = -0.8F + (static_cast<float>(i) / 20.0F) * kick_e;
            points->add_point({ .position = glm::vec3(-0.6F, y, 0.0F),
                .color = glm::vec3(1.0F, 0.2F, 0.2F),
                .size = 15.0F });
        }
        for (int i = 0; i < 20; ++i) {
            float y = -0.8F + (static_cast<float>(i) / 20.0F) * snare_e;
            points->add_point({ .position = glm::vec3(0.0F, y, 0.0F),
                .color = glm::vec3(0.2F, 1.0F, 0.2F),
                .size = 15.0F });
        }
        for (int i = 0; i < 20; ++i) {
            float y = -0.8F + (static_cast<float>(i) / 20.0F) * hat_e;
            points->add_point({ .position = glm::vec3(0.6F, y, 0.0F),
                .color = glm::vec3(0.2F, 0.2F, 1.0F),
                .size = 15.0F });
        }
    });

    on_key_pressed(window, IO::Keys::Space, [state]() {
        state->sequencing = !state->sequencing;
    });
    on_key_pressed(window, IO::Keys::C, [state]() {
        state->chaos_mode = !state->chaos_mode;
    });
}

// =========================================================================
// B: Rhythm Topology
// =========================================================================
//
// Same drum engine. Visual representation shifts from bar meters to a
// spatial topology graph. Each drum hit deposits a point at a random
// location. TopologyGeneratorNode connects them via minimum spanning tree.
// Audio energy modulates connection count, line thickness, and color.
// Space: start/stop. C: chaos. R: clear. Mouse: add point manually.

void day2_b_rhythm_topology()
{
    auto window = create_window({ .title = "Rhythm Topology",
        .width = 1920,
        .height = 1080 });

    struct State {
        bool sequencing { };
        bool chaos_mode { };
        size_t k_neighbors { 3 };
    };
    auto state = std::make_shared<State>();

    auto kick_phasor = vega.Phasor(20.0, 1.0);
    auto kick_env = vega.Polynomial([](double x) { return std::exp(-x * 15.0); });
    kick_env->set_input_node(kick_phasor);
    auto kick_tone = vega.Sine(55.0) | Audio[0];
    kick_tone->set_amplitude_modulator(kick_env);

    auto snare_phasor = vega.Phasor(30.0, 1.0);
    auto snare_env = vega.Polynomial([](double x) { return std::exp(-x * 25.0); }) | Audio[0];
    snare_env->set_input_node(snare_phasor);
    auto snare_shaped = vega.FIR(vega.Random(), std::vector { 0.3, 0.4, 0.3 }) * snare_env;
    register_audio_node(snare_shaped, 1);

    auto hat_phasor = vega.Phasor(50.0, 1.0);
    auto hat_env = vega.Polynomial([](double x) { return std::exp(-x * 50.0); });
    hat_env->set_input_node(hat_phasor);
    auto hat_tone = vega.Sine(8000.0) | Audio[0];
    hat_tone->set_amplitude_modulator(hat_env);

    auto topology = vega.TopologyGeneratorNode(
                        Kinesis::ProximityMode::MINIMUM_SPANNING_TREE,
                        false, 200)
        | Graphics;
    topology->set_k_neighbors(state->k_neighbors);
    topology->set_line_color(glm::vec3(0.4F, 0.7F, 1.0F), false);
    topology->set_line_thickness(1.2F, false);

    for (int i = 0; i < 3; ++i) {
        float angle = (static_cast<float>(i) / 3.0F) * 6.28F;
        topology->add_point({ .position = glm::vec3(std::cos(angle) * 0.3F, std::sin(angle) * 0.3F, 0.0F),
            .color = glm::vec3(0.3F, 0.3F, 0.5F),
            .thickness = 1.0F });
    }
    topology->regenerate_topology();

    auto buffer = vega.GeometryBuffer(topology) | Graphics;
    buffer->setup_rendering({ .target_window = window,
        .topology = Portal::Graphics::PrimitiveTopology::LINE_LIST });
    window->show();

    schedule_metro(0.5, [kick_phasor, topology, state]() {
        if (!state->sequencing) return;
        kick_phasor->reset();
        auto angle = static_cast<float>(get_uniform_random(0.0, 6.28));
        auto radius = static_cast<float>(get_uniform_random(0.1, 0.4));
        topology->add_point({
            .position = glm::vec3(std::cos(angle) * radius, std::sin(angle) * radius - 0.2F, 0.0F),
            .color = glm::vec3(1.0F, 0.2F, 0.2F), .thickness = 2.5F }); }, "kick_layer");

    schedule_pattern(
        [](uint64_t step) { return (step % 4 == 2); },
        [snare_phasor, topology, state](std::any hit) {
            if (!state->sequencing)
                return;
            if (std::any_cast<bool>(hit)) {
                snare_phasor->reset();
                topology->add_point({ .position = glm::vec3(
                                          static_cast<float>(get_uniform_random(-0.6, 0.6)),
                                          static_cast<float>(get_uniform_random(0.0, 0.6)), 0.0F),
                    .color = glm::vec3(0.2F, 1.0F, 0.3F),
                    .thickness = 1.8F });
            }
        },
        0.25, "snare_pattern");

    schedule_pattern(
        [state](uint64_t step) {
            if (state->chaos_mode)
                return get_uniform_random(0.0, 1.0) > 0.6;
            return true;
        },
        [hat_phasor, topology, state](std::any hit) {
            if (!state->sequencing)
                return;
            if (std::any_cast<bool>(hit)) {
                hat_phasor->reset();
                auto a = static_cast<float>(get_uniform_random(0.0, 6.28));
                auto r = static_cast<float>(get_uniform_random(0.5, 0.85));
                topology->add_point({ .position = glm::vec3(std::cos(a) * r, std::sin(a) * r, 0.0F),
                    .color = glm::vec3(0.3F, 0.4F, 1.0F),
                    .thickness = 0.8F });
            }
        },
        0.125, "hat_pattern");

    schedule_metro(0.5, [topology, kick_tone, snare_shaped, hat_tone, state]() {
        if (topology->get_vertex_count() > 500) {
            topology->clear();
            return;
        }
        float kick_e = std::abs(static_cast<float>(kick_tone->get_last_output()));
        float snare_e = std::abs(static_cast<float>(snare_shaped->get_last_output()));
        float hat_e = std::abs(static_cast<float>(hat_tone->get_last_output()));
        float combined = kick_e * 0.5F + snare_e * 0.3F + hat_e * 0.2F;

        size_t target_k = 2 + static_cast<size_t>(kick_e * 4.0F);
        if (target_k != state->k_neighbors) {
            state->k_neighbors = target_k;
            topology->set_k_neighbors(state->k_neighbors);
        }
        float brightness = 0.3F + combined * 0.7F;
        topology->set_line_color(glm::vec3(brightness, brightness * 0.8F, 1.0F), false);
        topology->set_line_thickness(0.6F + kick_e * 2.0F, false);
        topology->regenerate_topology();
    });

    on_key_pressed(window, IO::Keys::Space, [state]() { state->sequencing = !state->sequencing; });
    on_key_pressed(window, IO::Keys::C, [state]() { state->chaos_mode = !state->chaos_mode; });
    on_key_pressed(window, IO::Keys::R, [topology]() { topology->clear(); });

    on_mouse_pressed(window, IO::MouseButtons::Left, [window, topology](double x, double y) {
        topology->add_point({ .position = glm::vec3(normalize_coords(x, y, window)),
            .color = glm::vec3(1.0F, 0.9F, 0.3F),
            .thickness = 3.0F });
    });
}

// =========================================================================
// C: Living Topology
// =========================================================================
//
// A fixed set of vertices in a Lissajous distribution. Topology connects
// them via MST. Audio displaces vertices from home positions each frame
// via update_point() (no graph rebuild per frame). Snare hits regenerate
// the graph from current deformed positions. Hat cycles proximity mode.
// Clap injects jitter. Bass drives thickness.
// Space: start/stop. C: chaos. Q/W/E: switch distribution.

void day2_c_living_topology()
{
    auto window = create_window({ .title = "Living Topology",
        .width = 1920,
        .height = 1080 });

    constexpr size_t N = 34;

    struct State {
        bool sequencing { };
        bool chaos_mode { };
        float expansion { };
        float shear { };
        uint32_t hat_count { };
        uint32_t mode_idx { };
        std::vector<glm::vec3> home = std::vector<glm::vec3>(N);
        std::vector<glm::vec3> jitter = std::vector<glm::vec3>(N, glm::vec3(0.0F));
    };
    auto state = std::make_shared<State>();

    auto kick_phasor = vega.Phasor(20.0, 1.0);
    auto kick_env = vega.Polynomial([](double x) { return std::exp(-x * 15.0); });
    kick_env->set_input_node(kick_phasor);
    auto kick = vega.Sine(55.0) | Audio[0];
    kick->set_amplitude_modulator(kick_env);

    auto snare_phasor = vega.Phasor(30.0, 1.0);
    auto snare_env = vega.Polynomial([](double x) { return std::exp(-x * 25.0); }) | Audio[1];
    snare_env->set_input_node(snare_phasor);
    auto snare = (vega.FIR(vega.Random(), std::vector { 0.3, 0.4, 0.3 })) * snare_env;
    register_audio_node(snare, 1);

    auto hat_phasor = vega.Phasor(50.0, 1.0);
    auto hat_env = vega.Polynomial([](double x) { return std::exp(-x * 50.0); });
    hat_env->set_input_node(hat_phasor);
    auto hat = vega.Sine(8000.0) | Audio[0];
    hat->set_amplitude_modulator(hat_env);

    auto clap_phasor = vega.Phasor(40.0, 1.0);
    auto clap_env = vega.Polynomial([](double x) {
        return std::exp(-x * 35.0) * (1.0 + 0.3 * std::sin(x * 200.0));
    });
    clap_env->set_input_node(clap_phasor);
    auto clap = (vega.FIR(vega.Random(), std::vector { 0.1, 0.2, 0.4, 0.2, 0.1 })) * clap_env;
    register_audio_node(clap, 0);

    auto bass = vega.Sine(42.0) | Audio[{ 0, 1 }];
    bass->set_amplitude_modulator(vega.Sine(0.15, 0.12));

    auto topo = vega.TopologyGeneratorNode(
                    Kinesis::ProximityMode::MINIMUM_SPANNING_TREE,
                    false, N)
        | Graphics;

    {
        Kinesis::Stochastic::Stochastic rng;
        Kinesis::SamplerBounds bounds { glm::vec3(-0.65F), glm::vec3(0.65F) };
        auto samples = Kinesis::generate_samples(
            Kinesis::SpatialDistribution::LISSAJOUS, N, bounds, rng);
        for (size_t i = 0; i < N; ++i) {
            state->home[i] = samples[i].position;
            topo->add_point({ .position = samples[i].position,
                .color = samples[i].color,
                .thickness = 1.5F });
        }
        topo->regenerate_topology();
    }

    auto buffer = vega.GeometryBuffer(topo) | Graphics;
    buffer->setup_rendering({ .target_window = window,
        .topology = Portal::Graphics::PrimitiveTopology::LINE_LIST });
    window->show();

    schedule_metro(0.5, [kick_phasor, state]() {
        if (!state->sequencing) return;
        kick_phasor->reset();
        state->expansion = std::min(state->expansion + 0.25F, 1.2F); }, "kick_layer");

    schedule_pattern(
        [state](uint64_t step) {
            if (state->chaos_mode)
                return get_uniform_random(0.0, 1.0) > 0.6;
            return (step % 4 == 2);
        },
        [snare_phasor, topo, state](std::any hit) {
            if (!state->sequencing)
                return;
            if (std::any_cast<bool>(hit)) {
                snare_phasor->reset();
                state->shear += 0.2F;
                topo->regenerate_topology();
            }
        },
        0.25, "snare_pattern");

    schedule_pattern(
        [state](uint64_t step) {
            if (state->chaos_mode)
                return get_uniform_random(0.0, 1.0) > 0.5;
            return true;
        },
        [hat_phasor, topo, state](std::any hit) {
            if (!state->sequencing)
                return;
            if (std::any_cast<bool>(hit)) {
                hat_phasor->reset();
                state->hat_count++;
                if (state->hat_count >= 16) {
                    state->hat_count = 0;
                    static constexpr std::array modes = {
                        Kinesis::ProximityMode::MINIMUM_SPANNING_TREE,
                        Kinesis::ProximityMode::K_NEAREST,
                        Kinesis::ProximityMode::NEAREST_NEIGHBOR,
                        Kinesis::ProximityMode::SEQUENTIAL,
                    };
                    state->mode_idx = (state->mode_idx + 1) % modes.size();
                    topo->set_connection_mode(modes[state->mode_idx]);
                }
            }
        },
        0.125, "hat_pattern");

    schedule_pattern(
        [state](uint64_t step) {
            if (state->chaos_mode)
                return get_uniform_random(0.0, 1.0) > 0.8;
            return (step % 8 == 5);
        },
        [clap_phasor, state](std::any hit) {
            if (!state->sequencing)
                return;
            if (std::any_cast<bool>(hit)) {
                clap_phasor->reset();
                for (auto& j : state->jitter)
                    j = glm::vec3(
                        static_cast<float>(get_uniform_random(-0.1, 0.1)),
                        static_cast<float>(get_uniform_random(-0.1, 0.1)), 0.0F);
            }
        },
        0.25, "clap_pattern");

    schedule_metro(0.016, [topo, kick, bass, state]() {
        float kick_e = static_cast<float>(std::abs(kick->get_last_output()));
        float bass_e = static_cast<float>(std::abs(bass->get_last_output()));

        state->expansion *= 0.97F;
        state->shear *= 0.985F;

        for (size_t i = 0; i < N; ++i) {
            glm::vec3 home = state->home[i];
            glm::vec3 pos = home;

            float dist = glm::length(glm::vec2(home));
            if (dist > 0.001F) {
                glm::vec3 radial = glm::normalize(glm::vec3(home.x, home.y, 0.0F));
                pos += radial * state->expansion * 0.25F;
            }

            float sign = (home.y > 0.0F) ? 1.0F : -1.0F;
            float a = state->shear * sign;
            pos = glm::vec3(
                pos.x * std::cos(a) - pos.y * std::sin(a),
                pos.x * std::sin(a) + pos.y * std::cos(a),
                pos.z);

            state->jitter[i] *= 0.93F;
            pos += state->jitter[i];

            float brightness = 0.3F + kick_e * 2.0F;
            float pct = static_cast<float>(i) / static_cast<float>(N);
            brightness *= pct;
            topo->update_point(i, { .position = pos, .color = glm::vec3(brightness * 0.6F, brightness * 0.8F, std::min(1.0F, brightness)), .thickness = 1.0F + (bass_e * 1.2F) * pct });
        }
    });

    on_key_pressed(window, IO::Keys::Space, [state]() { state->sequencing = !state->sequencing; });
    on_key_pressed(window, IO::Keys::C, [state]() { state->chaos_mode = !state->chaos_mode; });

    auto regen_homes = [topo, state](Kinesis::SpatialDistribution dist) {
        Kinesis::Stochastic::Stochastic rng;
        Kinesis::SamplerBounds bounds { glm::vec3(-0.65F), glm::vec3(0.65F) };
        auto samples = Kinesis::generate_samples(dist, N, bounds, rng);
        for (size_t i = 0; i < N; ++i)
            state->home[i] = samples[i].position;
        topo->regenerate_topology();
    };

    on_key_pressed(window, IO::Keys::Q, [regen_homes]() { regen_homes(Kinesis::SpatialDistribution::LISSAJOUS); });
    on_key_pressed(window, IO::Keys::W, [regen_homes]() { regen_homes(Kinesis::SpatialDistribution::FIBONACCI_SPHERE); });
    on_key_pressed(window, IO::Keys::E, [regen_homes]() { regen_homes(Kinesis::SpatialDistribution::TORUS); });

    on_mouse_pressed(window, IO::MouseButtons::Left, [window, topo](double x, double y) {
        topo->add_point({ .position = glm::vec3(normalize_coords(x, y, window)),
            .color = glm::vec3(1.0F, 0.9F, 0.4F),
            .thickness = 2.5F });
        topo->regenerate_topology();
    });
}

// =========================================================================
// D: Rhythm Particles
// =========================================================================
//
// Same five-layer drum engine. Visual representation is a physically
// simulated particle field. Each drum layer imparts distinct forces:
// kick = radial impulse, snare = toggle spatial interactions,
// hat = orbital attractor, clap = toggle boundary mode.
// Bass drone modulates drag via parameter mapping.
// Q/W/E: physics material presets. Mouse: set/clear attractor.

void day2_d_rhythm_particles()
{
    auto window = create_window({ .title = "Rhythm Particles",
        .width = 1920,
        .height = 1080 });
    window->show();

    struct State {
        bool sequencing { };
        bool chaos_mode { };
        int routing_mode { };
        bool ping_pong_left { true };
        uint32_t snare_count { };
        float orbit_angle { };
        float compression { };
    };
    auto state = std::make_shared<State>();

    auto kick_phasor = vega.Phasor(20.0, 1.0);
    auto kick_env = vega.Polynomial([](double x) { return std::exp(-x * 15.0); });
    kick_env->set_input_node(kick_phasor);
    auto kick_tone = vega.Sine(55.0) | Audio[0];
    kick_tone->set_amplitude_modulator(kick_env);

    auto snare_phasor = vega.Phasor(30.0, 1.0);
    auto snare_env = vega.Polynomial([](double x) { return std::exp(-x * 25.0); }) | Audio[1];
    snare_env->set_input_node(snare_phasor);
    auto snare_shaped = vega.FIR(vega.Random(), std::vector { 0.3, 0.4, 0.3 }) * snare_env;
    register_audio_node(snare_shaped, 1);

    auto hat_phasor = vega.Phasor(50.0, 1.0);
    auto hat_env = vega.Polynomial([](double x) { return std::exp(-x * 50.0); });
    hat_env->set_input_node(hat_phasor);
    auto hat_tone = vega.Sine(8000.0) | Audio[0];
    hat_tone->set_amplitude_modulator(hat_env);

    auto bass_lfo = vega.Sine(0.15, 0.12);
    auto bass_tone = vega.Sine(42.0) | Audio[{ 0, 1 }];
    bass_tone->set_amplitude_modulator(bass_lfo);

    auto clap_phasor = vega.Phasor(40.0, 1.0);
    auto clap_env = vega.Polynomial([](double x) {
        return std::exp(-x * 35.0) * (1.0 + 0.3 * std::sin(x * 200.0));
    });
    clap_env->set_input_node(clap_phasor);
    auto clap_shaped = vega.FIR(vega.Random(), std::vector { 0.1, 0.2, 0.4, 0.2, 0.1 }) * clap_env;
    register_audio_node(clap_shaped, 0);

    auto particles = vega.ParticleNetwork(
                         120,
                         glm::vec3(-0.7F, -0.7F, -0.3F),
                         glm::vec3(0.7F, 0.7F, 0.3F),
                         Kinesis::SpatialDistribution::FIBONACCI_SPHERE)
        | Graphics;
    particles->set_topology(Topology::SPATIAL);

    auto physics = particles->create_operator<PhysicsOperator>();
    physics->set_gravity(glm::vec3(0.0F));
    physics->set_drag(0.06F);
    physics->set_bounds_mode(PhysicsOperator::BoundsMode::WRAP);
    physics->set_point_size(5.0F);
    physics->set_interaction_radius(0.25F);
    physics->set_spring_stiffness(0.02F);
    physics->set_repulsion_strength(0.4F);
    physics->enable_spatial_interactions(true);

    auto drag_modulator = vega.Polynomial([](double x) {
        return 0.04 + std::abs(x) * 0.08;
    }) | Audio[0];
    drag_modulator->set_input_node(bass_lfo);
    particles->map_parameter("drag", drag_modulator, MappingMode::BROADCAST);

    auto geom_buf = vega.NetworkGeometryBuffer(particles) | Graphics;
    geom_buf->setup_rendering({ .target_window = window });

    schedule_metro(0.5, [kick_phasor, kick_tone, physics, state]() {
        if (!state->sequencing) return;
        kick_phasor->reset();
        if (state->routing_mode == 3) {
            uint32_t ch = state->ping_pong_left ? 0 : 1;
            route_node(kick_tone, { ch }, 0.4);
            state->ping_pong_left = !state->ping_pong_left;
        }
        state->compression = std::min(state->compression + 0.4F, 3.0F);
        physics->set_parameter("attraction_strength", static_cast<double>(state->compression)); }, "kick_layer");

    schedule_pattern(
        [state](uint64_t step) {
            if (state->chaos_mode)
                return get_uniform_random(0.0, 1.0) > 0.6;
            return (step % 4 == 2);
        },
        [snare_phasor, physics, state](std::any hit) {
            if (!state->sequencing)
                return;
            if (std::any_cast<bool>(hit)) {
                snare_phasor->reset();
                state->snare_count++;
                bool crystalline = (state->snare_count % 2 == 1);
                physics->enable_spatial_interactions(crystalline);
                physics->set_spring_stiffness(crystalline ? 0.04F : 0.005F);
                physics->set_repulsion_strength(crystalline ? 0.6F : 0.1F);
            }
        },
        0.25, "snare_pattern");

    schedule_pattern(
        [state](uint64_t step) {
            if (state->chaos_mode)
                return get_uniform_random(0.0, 1.0) > 0.5;
            return true;
        },
        [hat_phasor, physics, state](std::any hit) {
            if (!state->sequencing)
                return;
            if (std::any_cast<bool>(hit)) {
                hat_phasor->reset();
                state->orbit_angle += 0.4F;
                float r = 0.35F;
                physics->set_attraction_point(glm::vec3(
                    std::cos(state->orbit_angle) * r,
                    std::sin(state->orbit_angle) * r,
                    std::sin(state->orbit_angle * 0.7F) * 0.1F));
            }
        },
        0.125, "hat_pattern");

    schedule_pattern(
        [state](uint64_t step) {
            if (state->chaos_mode)
                return get_uniform_random(0.0, 1.0) > 0.8;
            return (step % 8 == 5);
        },
        [clap_phasor, physics](std::any hit) {
            if (std::any_cast<bool>(hit)) {
                clap_phasor->reset();
                auto current = physics->get_bounds_mode();
                physics->set_bounds_mode(
                    current == PhysicsOperator::BoundsMode::WRAP
                        ? PhysicsOperator::BoundsMode::BOUNCE
                        : PhysicsOperator::BoundsMode::WRAP);
            }
        },
        0.25, "clap_pattern");

    schedule_metro(0.05, [physics, snare_env, state]() {
        state->compression *= 0.96F;
        if (state->compression < 0.05F && !physics->has_attraction_point()) {
            physics->set_parameter("attraction_strength", 0.0);
        } else {
            physics->set_parameter("attraction_strength", static_cast<double>(state->compression));
        }
        float snare_e = static_cast<float>(std::abs(snare_env->get_last_output()));
        physics->set_interaction_radius(0.15F + snare_e * 0.25F);
    });

    on_key_pressed(window, IO::Keys::Space, [state]() { state->sequencing = !state->sequencing; });
    on_key_pressed(window, IO::Keys::C, [state]() { state->chaos_mode = !state->chaos_mode; });
    on_key_pressed(window, IO::Keys::R, [physics, state]() {
        physics->apply_global_impulse(glm::vec3(0.0F));
        physics->set_gravity(glm::vec3(0.0F));
        physics->clear_attraction_point();
        state->compression = 0.0F;
        state->orbit_angle = 0.0F;
        state->snare_count = 0;
    });

    on_key_pressed(window, IO::Keys::Q, [physics]() {
        physics->set_spring_stiffness(0.06F);
        physics->set_drag(0.02F);
        physics->set_interaction_radius(0.15F);
        physics->set_repulsion_strength(0.8F);
        physics->enable_spatial_interactions(true);
    });
    on_key_pressed(window, IO::Keys::W, [physics]() {
        physics->set_spring_stiffness(0.015F);
        physics->set_drag(0.08F);
        physics->set_interaction_radius(0.3F);
        physics->set_repulsion_strength(0.3F);
        physics->enable_spatial_interactions(true);
    });
    on_key_pressed(window, IO::Keys::E, [physics]() {
        physics->enable_spatial_interactions(false);
        physics->set_drag(0.01F);
    });

    on_mouse_pressed(window, IO::MouseButtons::Left, [window, physics](double x, double y) {
        glm::vec2 pos = normalize_coords(x, y, window);
        physics->set_attraction_point(glm::vec3(pos, 0.0F));
    });
    on_mouse_pressed(window, IO::MouseButtons::Right, [physics](double, double) {
        physics->clear_attraction_point();
    });

    on_key_pressed(window, IO::Keys::N1, [kick_tone, snare_shaped, hat_tone, clap_shaped, state]() {
        state->routing_mode = 0;
        route_node(kick_tone, { 0 }, 1.5);
        route_node(snare_shaped, { 0 }, 1.5);
        route_node(hat_tone, { 0 }, 1.5);
        route_node(clap_shaped, { 0 }, 1.5);
    });
    on_key_pressed(window, IO::Keys::N2, [kick_tone, snare_shaped, hat_tone, clap_shaped, state]() {
        state->routing_mode = 1;
        route_node(kick_tone, { 1 }, 1.5);
        route_node(snare_shaped, { 1 }, 1.5);
        route_node(hat_tone, { 1 }, 1.5);
        route_node(clap_shaped, { 1 }, 1.5);
    });
    on_key_pressed(window, IO::Keys::N3, [kick_tone, snare_shaped, hat_tone, clap_shaped, state]() {
        state->routing_mode = 2;
        route_node(kick_tone, { 0, 1 }, 2.0);
        route_node(snare_shaped, { 0, 1 }, 2.0);
        route_node(hat_tone, { 0, 1 }, 2.0);
        route_node(clap_shaped, { 0, 1 }, 2.0);
    });
    on_key_pressed(window, IO::Keys::N4, [kick_tone, snare_shaped, hat_tone, clap_shaped, state]() {
        state->routing_mode = 3;
        route_node(snare_shaped, { 0, 1 }, 1.0);
        route_node(hat_tone, { 0, 1 }, 1.0);
        route_node(clap_shaped, { 0, 1 }, 1.0);
    });
}

// =========================================================================
// E: Composite Scene
// =========================================================================
//
// Three geometry types in one window via CompositeGeometryBuffer:
// a Catmull-Rom path (LINE_LIST), a topology graph (LINE_LIST),
// and energy dots (POINT_LIST). One GPU buffer upload, three draw calls
// with independent shaders and topologies.
// The drum engine drives all three: kick deforms the path, snare
// regenerates the topology, hat adds energy dots.
// This demonstrates the third geometry organization method:
// manual composition of independent GeometryWriterNodes into a single
// buffer, each rendered with its own pipeline.

void day2_e_composite_scene()
{
    auto window = create_window({ .title = "Composite Scene",
        .width = 1920,
        .height = 1080 });

    struct State {
        bool sequencing { };
        bool chaos_mode { };
        float expansion { };
        std::array<float, 12> phases { };
    };
    auto state = std::make_shared<State>();

    for (size_t i = 0; i < 12; ++i)
        state->phases[i] = static_cast<float>(i) / 12.0F * 6.2832F;

    auto kick_phasor = vega.Phasor(20.0, 1.0);
    auto kick_env = vega.Polynomial([](double x) { return std::exp(-x * 15.0); });
    kick_env->set_input_node(kick_phasor);
    auto kick = vega.Sine(55.0) | Audio[0];
    kick->set_amplitude_modulator(kick_env);

    auto snare_phasor = vega.Phasor(30.0, 1.0);
    auto snare_env = vega.Polynomial([](double x) { return std::exp(-x * 25.0); }) | Audio[1];
    snare_env->set_input_node(snare_phasor);
    auto snare = vega.FIR(vega.Random(), std::vector { 0.3, 0.4, 0.3 }) * snare_env;
    register_audio_node(snare, 1);

    auto hat_phasor = vega.Phasor(50.0, 1.0);
    auto hat_env = vega.Polynomial([](double x) { return std::exp(-x * 50.0); });
    hat_env->set_input_node(hat_phasor);
    auto hat = vega.Sine(8000.0) | Audio[0];
    hat->set_amplitude_modulator(hat_env);

    auto path = vega.PathGeneratorNode(
                    Kinesis::InterpolationMode::CATMULL_ROM, 24, 12, 0.5)
        | Graphics;

    for (size_t i = 0; i < 12; ++i) {
        float phase = state->phases[i];
        float hue = static_cast<float>(i) / 12.0F;
        path->add_control_point({ .position = glm::vec3(std::sin(phase) * 0.4F, std::sin(phase * 1.5F) * 0.3F, 0.0F),
            .color = glm::vec3(0.4F + hue * 0.5F, 0.6F, 1.0F - hue * 0.4F),
            .thickness = 2.0F });
    }

    auto topo = vega.TopologyGeneratorNode(
                    Kinesis::ProximityMode::K_NEAREST, false, 30)
        | Graphics;
    topo->set_k_neighbors(2);
    topo->set_line_color(glm::vec3(0.5F, 0.3F, 0.8F), false);
    topo->set_line_thickness(1.0F, false);

    for (int i = 0; i < 8; ++i) {
        auto a = static_cast<float>(get_uniform_random(0.0, 6.28));
        auto r = static_cast<float>(get_uniform_random(0.3, 0.7));
        topo->add_point({ .position = glm::vec3(std::cos(a) * r, std::sin(a) * r, 0.0F),
            .color = glm::vec3(0.5F, 0.3F, 0.8F),
            .thickness = 1.0F });
    }
    topo->regenerate_topology();

    auto dots = vega.PointCollectionNode(200) | Graphics;

    auto composite = std::make_shared<CompositeGeometryBuffer>();
    register_graphics_buffer(composite);
    // composite->setup_processors(Buffers::ProcessingToken::GRAPHICS_BACKEND);
    composite->add_geometry("path", path, Portal::Graphics::PrimitiveTopology::LINE_LIST, window);
    composite->add_geometry("topo", topo, Portal::Graphics::PrimitiveTopology::LINE_LIST, window);
    composite->add_geometry("dots", dots, Portal::Graphics::PrimitiveTopology::POINT_LIST, window);

    window->show();

    schedule_metro(0.5, [kick_phasor, state]() {
        if (!state->sequencing) return;
        kick_phasor->reset();
        state->expansion = std::min(state->expansion + 0.2F, 0.8F); }, "kick_layer");

    schedule_pattern(
        [](uint64_t step) { return (step % 4 == 2); },
        [snare_phasor, topo, state](std::any hit) {
            if (!state->sequencing)
                return;
            if (std::any_cast<bool>(hit)) {
                snare_phasor->reset();
                auto a = static_cast<float>(get_uniform_random(0.0, 6.28));
                auto r = static_cast<float>(get_uniform_random(0.3, 0.7));
                topo->add_point({ .position = glm::vec3(std::cos(a) * r, std::sin(a) * r, 0.0F),
                    .color = glm::vec3(0.5F, 0.3F, 0.8F),
                    .thickness = 1.5F });
                topo->regenerate_topology();
            }
        },
        0.25, "snare_pattern");

    schedule_pattern(
        [state](uint64_t step) {
            if (state->chaos_mode)
                return get_uniform_random(0.0, 1.0) > 0.5;
            return true;
        },
        [hat_phasor, dots, state](std::any hit) {
            if (!state->sequencing)
                return;
            if (std::any_cast<bool>(hit)) {
                hat_phasor->reset();
                auto a = static_cast<float>(get_uniform_random(0.0, 6.28));
                auto r = static_cast<float>(get_uniform_random(0.1, 0.9));
                dots->add_point({ .position = glm::vec3(std::cos(a) * r, std::sin(a) * r, 0.0F),
                    .color = glm::vec3(1.0F, 0.9F, 0.3F),
                    .size = static_cast<float>(get_uniform_random(4.0, 12.0)) });
                if (dots->get_point_count() > 200)
                    dots->clear_points();
            }
        },
        0.125, "hat_pattern");

    schedule_metro(0.016, [path, kick, state]() {
        float kick_e = static_cast<float>(std::abs(kick->get_last_output()));
        state->expansion *= 0.97F;

        for (size_t i = 0; i < 12; ++i) {
            state->phases[i] += 0.008F + static_cast<float>(i) * 0.001F;
            float phase = state->phases[i];
            float base_x = std::sin(phase) * 0.4F;
            float base_y = std::sin(phase * 1.5F) * 0.3F;

            float dist = std::sqrt(base_x * base_x + base_y * base_y);
            float expand = (dist > 0.001F) ? state->expansion * 0.3F / dist : 0.0F;
            float x = base_x * (1.0F + expand);
            float y = base_y * (1.0F + expand);

            float hue = static_cast<float>(i) / 12.0F;
            float brightness = 0.4F + kick_e * 1.5F;

            path->update_control_point(i, { .position = glm::vec3(x, y, 0.0F), .color = glm::vec3(brightness * (0.4F + hue * 0.5F), brightness * 0.7F, brightness * (1.0F - hue * 0.3F)), .thickness = 1.5F + kick_e * 3.0F });
        }
    });

    on_key_pressed(window, IO::Keys::Space, [state]() { state->sequencing = !state->sequencing; });
    on_key_pressed(window, IO::Keys::C, [state]() { state->chaos_mode = !state->chaos_mode; });
    on_key_pressed(window, IO::Keys::R, [topo, dots]() {
        topo->clear();
        dots->clear_points();
    });

    on_mouse_pressed(window, IO::MouseButtons::Left, [window, topo](double x, double y) {
        topo->add_point({ .position = glm::vec3(normalize_coords(x, y, window)),
            .color = glm::vec3(1.0F, 0.5F, 0.8F),
            .thickness = 2.0F });
        topo->regenerate_topology();
    });
}
