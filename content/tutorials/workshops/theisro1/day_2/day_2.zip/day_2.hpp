#pragma once

#define MAYASIMPLE
#include "MayaFlux/MayaFlux.hpp"

/// @brief Rhythm machine: kick/snare/hat via Phasor envelopes. Energy bar visuals.
void day2_a_rhythm_machine();

/// @brief Rhythm topology: drum hits deposit spatial points. Connections emerge from proximity.
void day2_b_rhythm_topology();

/// @brief Living topology: fixed vertex set deformed by audio. No graph rebuild per frame.
void day2_c_living_topology();

/// @brief Rhythm particles: ParticleNetwork with PhysicsOperator. Audio drives forces.
void day2_d_rhythm_particles();

/// @brief Composite scene: path + points + topology in one buffer via CompositeGeometryBuffer.
void day2_e_composite_scene();
