#version 450

layout(location = 0) in vec2 fragTexCoord;
layout(location = 0) out vec4 outColor;

layout(set = 0, binding = 1) uniform sampler2D texSampler;

layout(set = 1, binding = 0) buffer HistoryData {
    float values[];
} history;

layout(push_constant) uniform Params {
    float sample_count;
    float intensity;
};

void main() {
    vec2 uv = fragTexCoord;

    int idx = int(uv.y * sample_count);
    idx = clamp(idx, 0, int(sample_count) - 1);
    float displacement = history.values[idx] * 10;

    int idx_prev = clamp(idx - 1, 0, int(sample_count) - 1);
    int idx_next = clamp(idx + 1, 0, int(sample_count) - 1);
    float slope = (history.values[idx_next] - history.values[idx_prev]) * 0.5;

    uv.x += displacement * intensity;
    uv.y += slope * intensity * 0.3;

    vec4 tex = texture(texSampler, uv);

    float activity = abs(displacement) * 2.0;
    tex.rgb = mix(tex.rgb, tex.rgb * vec3(1.0 + activity, 1.0, 1.0 - activity * 0.5), intensity);

    outColor = tex;
}
