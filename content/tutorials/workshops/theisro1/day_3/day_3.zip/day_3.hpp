#pragma once

#define MAYASIMPLE
#include "MayaFlux/MayaFlux.hpp"

// ============================================================================
// PART 1: Push Constants (data → GPU, manual and automated)
// ============================================================================

/// @brief Static push constants: struct → GPU. No nodes, no automation.
void day3_a_static_tint();

/// @brief One node drives one shader field via scheduled metro callback.
void day3_b_first_crossing();

/// @brief NodeBindingsProcessor: multiple nodes bound to push constant offsets.
void day3_c_dual_stream();

/// @brief Audio resonator drives vertex displacement. Geometry breathes with sound.
void day3_d_breathing_geometry();

/// @brief Polar warp with three independent modulation streams. Camera input.
void day3_e_polar_warp();

// ============================================================================
// PART 2: Descriptor Bindings (SSBO — large data to GPU)
// ============================================================================

/// @brief Delay network history (400 samples) as SSBO. Camera input. Fragment reads history directly.
void day3_f_history_field();

/// @brief Live audio input buffer as SSBO. Microphone waveform displaces video file.
void day3_g_audio_input_field();

/// @brief ResonatorNetwork output as SSBO. Camera input. Vowel presets. Network excitation switching.
void day3_h_network_descriptor();

// ============================================================================
// PART 3: GPU Geometry (vertex shader computes positions from push constants)
// ============================================================================

/// @brief Phasor ring: 360 static vertices repositioned entirely by vertex shader.
void day3_i_phasor_ring();

/// @brief Wave mesh: 80x80 grid displaced by audio-driven sine fields. Video file input for texture.
void day3_j_wave_mesh();

/// @brief Orbit cloud: 1000 vertices on elliptical orbits computed in vertex shader. Audio contracts orbits.
void day3_k_orbit_cloud();

/// @brief IFS tree: 2048 vertices positioned by iterated function system in vertex shader. Audio bends branches.
void day3_l_ifs_tree();

void simple();
