#include "day_3.hpp"

// =========================================================================
// PART 1: PUSH CONSTANTS
// =========================================================================

// -------------------------------------------------------------------------
// A: Static Tint
// -------------------------------------------------------------------------
//
// The simplest shader interaction. Define a struct. Fill it with numbers.
// The fragment shader sees those numbers as push constants.
// No nodes. No automation. Just data → GPU.

void day3_a_static_tint()
{
    auto window = create_window({ .title = "Static Tint",
        .width = 1920,
        .height = 1080 });

    auto tex = vega.read_image("res/texture.png") | Graphics;

    tex->setup_rendering({
        .target_window = window,
        .fragment_shader = "tint.frag",
    });

    struct Params {
        float tint_r;
        float tint_g;
        float tint_b;
        float brightness;
    };

    Params p { .tint_r = 0.2F, .tint_g = 0.6F, .tint_b = 0.9F, .brightness = 0.5F };

    auto rp = tex->get_render_processor();
    rp->set_push_constant_size<Params>();
    rp->set_push_constant_data(p);

    window->show();
}

// -------------------------------------------------------------------------
// B: First Crossing
// -------------------------------------------------------------------------
//
// One sine oscillator drives one shader parameter. The fragment shader
// receives a continuously changing warp_amount that displaces texture
// coordinates. Everything else stays constant. Metro callback pushes
// the updated struct every frame.

void day3_b_first_crossing()
{
    auto window = create_window({ .title = "First Crossing",
        .width = 1920,
        .height = 1080 });

    auto tex = vega.read_image("res/texture.png") | Graphics;

    tex->setup_rendering({
        .target_window = window,
        .fragment_shader = "first_warp.frag",
    });

    window->show();

    struct Params {
        float tint_r = 1.0F;
        float tint_g = 1.0F;
        float tint_b = 1.0F;
        float brightness = 1.0F;
        float warp_amount = 0.0F;
    };

    auto rp = tex->get_render_processor();
    rp->set_push_constant_size<Params>();
    rp->set_push_constant_data(Params { });

    auto warp = vega.Sine(2, 1.0) | Graphics;

    schedule_metro(0.016, [rp, warp]() {
        Params p { };
        p.warp_amount = static_cast<float>(warp->get_last_output());
        rp->set_push_constant_data(p);
    });
}

// -------------------------------------------------------------------------
// C: Dual Stream (NodeBindingsProcessor)
// -------------------------------------------------------------------------
//
// Two independent audio streams deform the same image. Stream A: recursive
// delay network building interference patterns. Stream B: non-linear
// probability shaping. Both bound to separate push constant fields via
// NodeBindingsProcessor. Constant node provides aspect ratio cleanly.

void day3_c_dual_stream()
{
    auto window = create_window({ .title = "Dual Stream",
        .width = 1920,
        .height = 1080 });

    auto tex = vega.read_image("res/texture.png") | Graphics;

    tex->setup_rendering({
        .target_window = window,
        .fragment_shader = "dual_stream.frag",
    });

    struct Params {
        float aspect = 16.0F / 9.0F;
        float displacement_a = 0.0F;
        float displacement_b = 0.0F;
    };

    auto noise = vega.Random() | Graphics;

    auto delay_net = vega.Polynomial(
                         [noise](std::span<double> h) {
                             double in = noise->get_last_output() * 0.04;
                             return in + h[41] * 0.38 + h[89] * 0.27 - h[179] * 0.19 + h[359] * 0.13;
                         },
                         PolynomialMode::RECURSIVE,
                         400)
        | Audio[0];
    delay_net->set_initial_conditions({ 0.6, -0.2, 0.4, -0.1 });

    auto noise2 = vega.Random() | Graphics;

    auto stochastic = vega.Polynomial(
                          [noise2](double x) {
                              double n = noise2->process_sample(0.0);
                              return std::pow(std::abs(x), 1.8) * (x > 0 ? 1.0 : -1.0) * n;
                          })
        | Audio[1];
    stochastic->set_input_node(delay_net);

    auto aspect = vega.Constant(16.0 / 9.0) | Graphics;

    auto shader_config = Buffers::ShaderConfig { "dual_stream.frag" };
    shader_config.push_constant_size = sizeof(Params);

    auto node_bindings = std::make_shared<Buffers::NodeBindingsProcessor>(shader_config);
    node_bindings->set_push_constant_size<Params>();
    node_bindings->bind_node("aspect", aspect, offsetof(Params, aspect), sizeof(float));
    node_bindings->bind_node("a", delay_net, offsetof(Params, displacement_a), sizeof(float));
    node_bindings->bind_node("b", stochastic, offsetof(Params, displacement_b), sizeof(float));

    add_processor(node_bindings, tex, Buffers::ProcessingToken::GRAPHICS_BACKEND);

    window->show();
}

// -------------------------------------------------------------------------
// D: Breathing Geometry
// -------------------------------------------------------------------------
//
// Audio resonator drives vertex displacement. A recursive delay line
// produces decaying resonance. Its envelope is extracted via full-wave
// rectification and bound to a vertex shader that displaces the image
// quad. The geometry breathes with the sound.

void day3_d_breathing_geometry()
{
    auto window = create_window({ .title = "Breathing Geometry",
        .width = 1920,
        .height = 1080 });

    auto tex = vega.read_image("res/sc.png") | Graphics;

    tex->setup_rendering({
        .target_window = window,
        .vertex_shader = "breathing.vert",
    });

    struct Params {
        float aspect = 16.0F / 9.0F;
        float displacement_scale = 0.0F;
    };

    auto noise = vega.Random() | Graphics;
    auto wobble = vega.Sine(200, 1.0);

    struct TrigState {
        double last = 0.0;
    };
    auto trig = std::make_shared<TrigState>();

    auto gate = vega.Logic([trig](double x) {
        bool crossed = (trig->last < 0.0) && (x >= 0.0);
        trig->last = x;
        return crossed;
    }) | Graphics;
    gate->set_input_node(wobble);

    auto resonator = vega.Polynomial(
                         [gate, noise](std::span<double> h) {
                             double impulse = 0.0;
                             if (gate->get_last_output() > 0.0) {
                                 impulse = noise->get_last_output() * 0.8;
                             }
                             return impulse + h[200] * 0.985;
                         },
                         PolynomialMode::RECURSIVE,
                         256)
        | Audio[0];

    auto envelope = vega.Polynomial([](double x) {
        return std::abs(x);
    }) | Audio[1];
    envelope->set_input_node(resonator);

    auto aspect = vega.Constant(16.0 / 9.0) | Graphics;

    auto shader_config = Buffers::ShaderConfig { "breathing.vert" };
    shader_config.push_constant_size = sizeof(Params);

    auto node_bindings = std::make_shared<Buffers::NodeBindingsProcessor>(shader_config);
    node_bindings->set_push_constant_size<Params>();
    node_bindings->bind_node("aspect", aspect, offsetof(Params, aspect), sizeof(float));
    node_bindings->bind_node("displacement", envelope, offsetof(Params, displacement_scale), sizeof(float));

    add_processor(node_bindings, tex, Buffers::ProcessingToken::GRAPHICS_BACKEND);

    window->show();
}

// -------------------------------------------------------------------------
// E: Polar Warp (Camera)
// -------------------------------------------------------------------------
//
// Three independent modulation streams drive polar coordinate distortion
// of live camera input. Radial scale, angular velocity, chromatic
// aberration split. Camera replaces static image.

void day3_e_polar_warp()
{
    auto window = create_window({ .title = "Polar Warp",
        .width = 1920,
        .height = 1080 });

    auto manager = get_io_manager();
    auto camera = manager->open_camera({ .device_name = "/dev/video0",
        .target_width = 1920,
        .target_height = 1080,
        .target_fps = 30 });
    auto tex = manager->hook_camera_to_buffer(camera);

    tex->setup_rendering({
        .target_window = window,
        .fragment_shader = "polar_warp.frag",
    });

    window->show();

    struct Params {
        float radial_scale = 0.0F;
        float angular_velocity = 0.0F;
        float chroma_split = 0.0F;
    };

    auto radial = vega.Sine(0.08, 0.4) | Graphics;
    auto angular = vega.Sine(0.15, 2.0) | Graphics;

    auto noise = vega.Random();
    auto chroma_raw = vega.Polynomial([](double x) {
        return std::abs(x) * 0.12;
        // }) | Graphics;
    });
    chroma_raw->set_input_node(noise);

    auto chroma_smooth = vega.Polynomial(
                             [chroma_raw](std::span<double> h) {
                                 double current = chroma_raw->get_last_output();
                                 double avg = 0.0;
                                 int count = std::min(static_cast<int>(h.size()), 32);
                                 for (int i = 0; i < count; ++i)
                                     avg += h[i];
                                 avg /= static_cast<double>(count);
                                 return avg * 0.7 + current * 0.3;
                             },
                             PolynomialMode::FEEDFORWARD,
                             64)
        | Graphics;
    chroma_smooth->set_input_node(chroma_raw);

    auto shader_config = Buffers::ShaderConfig { "polar_warp.frag" };
    shader_config.push_constant_size = sizeof(Params);

    auto node_bindings = std::make_shared<Buffers::NodeBindingsProcessor>(shader_config);
    node_bindings->set_push_constant_size<Params>();
    node_bindings->bind_node("radial", radial, offsetof(Params, radial_scale), sizeof(float));
    node_bindings->bind_node("angular", angular, offsetof(Params, angular_velocity), sizeof(float));
    node_bindings->bind_node("chroma", chroma_smooth, offsetof(Params, chroma_split), sizeof(float));

    add_processor(node_bindings, tex, Buffers::ProcessingToken::GRAPHICS_BACKEND);
}

// =========================================================================
// PART 2: DESCRIPTOR BINDINGS (SSBO)
// =========================================================================

// -------------------------------------------------------------------------
// F: History Field (Camera + SSBO)
// -------------------------------------------------------------------------
//
// A recursive delay network generates audio. Its entire history buffer
// (400 samples) is uploaded to the GPU as a storage buffer every frame.
// The fragment shader reads this history directly, using it as a 1D
// displacement map across the image height. Camera provides the source.
//
// Push constants carry sample_count and intensity (small values).
// SSBO carries the 400-float history (too large for push constants).

void day3_f_history_field()
{
    auto window = create_window({ .title = "History Field",
        .width = 1920,
        .height = 1080 });

    auto manager = get_io_manager();

    auto camera = manager->open_camera({ .device_name = "/dev/video0",
        .target_width = 1920,
        .target_height = 1080,
        .target_fps = 30 });

    auto tex = manager->hook_camera_to_buffer(camera);

    tex->setup_rendering({
        .target_window = window,
        .fragment_shader = "hist_field.frag",
    });

    window->show();

    struct PushParams {
        float sample_count = 400.0F;
        float intensity = 0.3F;
    };

    auto noise = vega.Random() | Graphics;

    auto delay_net = vega.Polynomial(
                         [noise](std::span<double> h) {
                             double in = noise->get_last_output() * 0.05;
                             return in + h[53] * 0.36 + h[109] * 0.28 - h[227] * 0.17 + h[389] * 0.11;
                         },
                         PolynomialMode::RECURSIVE,
                         400)
        | Audio[0];

    delay_net->set_gpu_compatible(true);
    delay_net->set_initial_conditions({ 0.7, -0.4, 0.3, -0.1, 0.5 });

    auto intensity_lfo = vega.Sine(0.1, 0.15) | Graphics;
    auto intensity_node = vega.Polynomial(
                              [intensity_lfo](double) {
                                  return 0.3 + intensity_lfo->get_last_output();
                              })
        | Graphics;

    auto count_node = vega.Constant(400.0) | Graphics;

    auto shader_config = Buffers::ShaderConfig { "hist_field.frag" };
    shader_config.push_constant_size = sizeof(PushParams);
    shader_config.bindings["history_data"] = Buffers::ShaderBinding(1, 0, Portal::Graphics::DescriptorRole::STORAGE);

    auto desc_bindings = create_processor<Buffers::DescriptorBindingsProcessor>(tex, shader_config);
    desc_bindings->set_push_constant_size<PushParams>();
    desc_bindings->bind_vector_node("history", delay_net, "history_data", 1,
        Portal::Graphics::DescriptorRole::STORAGE,
        Buffers::DescriptorBindingsProcessor::ProcessingMode::EXTERNAL);

    auto push_bindings = create_processor<Buffers::NodeBindingsProcessor>(tex, shader_config);
    push_bindings->set_push_constant_size<PushParams>();
    push_bindings->bind_node("count", count_node, offsetof(PushParams, sample_count), sizeof(float));
    push_bindings->bind_node("intensity", intensity_node, offsetof(PushParams, intensity), sizeof(float));
}

// -------------------------------------------------------------------------
// G: Audio Input Field (Video File + Audio Input SSBO)
// -------------------------------------------------------------------------
//
// Live audio input captured as an SSBO. The microphone signal (512 samples
// per buffer cycle) is bound directly to the shader via bind_audio_buffer.
// The fragment shader reads the waveform and uses it as a displacement map
// over a video file. No intermediate node extraction, no manual copying.
// The audio buffer IS the data.

void day3_g_audio_input_field()
{
    auto window = create_window({ .title = "Audio Input Field",
        .width = 1920,
        .height = 1080 });

    auto manager = get_io_manager();
    auto video_result = manager->load_video("res/Lynch.mkv");
    auto tex = manager->hook_video_container_to_buffer(video_result);

    tex->setup_rendering({
        .target_window = window,
        .fragment_shader = "hist_field.frag",
    });

    window->show();

    struct PushParams {
        float sample_count = 512.0F;
        float intensity = 0.3F;
    };

    auto buf = create_input_listener_buffer(0);

    auto intensity_lfo = vega.Sine(0.1, 0.15) | Graphics;
    auto intensity_node = vega.Polynomial(
                              [intensity_lfo](double) {
                                  return 0.3 + intensity_lfo->get_last_output();
                              })
        | Graphics;
    auto count_node = vega.Constant(512.0) | Graphics;

    auto shader_config = Buffers::ShaderConfig { "hist_field.frag" };
    shader_config.push_constant_size = sizeof(PushParams);
    shader_config.bindings["history_data"] = Buffers::ShaderBinding(1, 0, vk::DescriptorType::eStorageBuffer);

    auto desc_bindings = std::make_shared<Buffers::DescriptorBindingsProcessor>(shader_config);
    desc_bindings->set_push_constant_size<PushParams>();
    desc_bindings->bind_audio_buffer("history", buf, "history_data", 1);

    auto push_bindings = std::make_shared<Buffers::NodeBindingsProcessor>(shader_config);
    push_bindings->set_push_constant_size<PushParams>();
    push_bindings->bind_node("count", count_node, offsetof(PushParams, sample_count), sizeof(float));
    push_bindings->bind_node("intensity", intensity_node, offsetof(PushParams, intensity), sizeof(float));

    add_processor(desc_bindings, tex, Buffers::ProcessingToken::GRAPHICS_BACKEND);
    add_processor(push_bindings, tex, Buffers::ProcessingToken::GRAPHICS_BACKEND);
}

// -------------------------------------------------------------------------
// H: Network Descriptor (Camera + ResonatorNetwork SSBO)
// -------------------------------------------------------------------------
//
// ResonatorNetwork output bound as SSBO. Camera input. The network's
// audio buffer (all resonator outputs mixed) feeds directly to the shader.
// Vowel presets switch formant profiles. Excitation source is switchable:
// Phasor (pitched), noise (breathy), WaveguideNetwork (string excites
// vocal tract), ModalNetwork (bell excites vocal tract).

void day3_h_network_descriptor()
{
    auto window = create_window({ .title = "Network Descriptor",
        .width = 1920,
        .height = 1080 });

    auto manager = get_io_manager();
    auto camera = manager->open_camera({ .device_name = "/dev/video0",
        .target_width = 1920,
        .target_height = 1080,
        .target_fps = 30 });
    auto tex = manager->hook_camera_to_buffer(camera);

    tex->setup_rendering({
        .target_window = window,
        .fragment_shader = "hist_field.frag",
    });

    window->show();

    struct PushParams {
        float sample_count = 400.0F;
        float intensity = 0.3F;
    };

    auto rn = vega.ResonatorNetwork(5, ResonatorNetwork::FormantPreset::VOWEL_A) | Audio[0];
    rn->add_channel_usage(1);

    auto wv = vega.WaveguideNetwork(WaveguideNetwork::WaveguideType::STRING, 220.0) | Audio[0];
    wv->set_output_scale(2);
    wv->set_output_mode(OutputMode::AUDIO_COMPUTE);

    auto models = vega.ModalNetwork(9, 220.0, ModalNetwork::Spectrum::INHARMONIC) | Audio[0];
    models->set_output_mode(OutputMode::AUDIO_COMPUTE);
    models->set_output_scale(2);

    auto exciter = vega.Phasor(120.F) | Graphics;
    rn->set_exciter(exciter);

    on_key_pressed(window, IO::Keys::Space, [rn]() {
        auto noise = vega.Random(Kinesis::Stochastic::Algorithm::NORMAL) | Graphics;
        rn->set_exciter(noise);
    });

    on_key_pressed(window, IO::Keys::Escape, [rn, exciter]() {
        exciter->reset(30.F);
        rn->set_exciter(exciter);
    });

    on_mouse_pressed(window, IO::MouseButtons::Left, [rn, exciter, window](double x, double y) {
        auto coords = normalize_coords(x, y, window);
        exciter->reset(coords.x * 80.F + 30.F);
        rn->set_exciter(exciter);
    });

    on_key_pressed(window, IO::Keys::Enter, [wv]() { wv->pluck(0.9, 0.9); });
    on_key_pressed(window, IO::Keys::Tab, [models]() { models->excite(0.6); });

    on_key_pressed(window, IO::Keys::A, [rn]() { rn->apply_preset(ResonatorNetwork::FormantPreset::VOWEL_A); });
    on_key_pressed(window, IO::Keys::E, [rn]() { rn->apply_preset(ResonatorNetwork::FormantPreset::VOWEL_E); });
    on_key_pressed(window, IO::Keys::I, [rn]() { rn->apply_preset(ResonatorNetwork::FormantPreset::VOWEL_I); });
    on_key_pressed(window, IO::Keys::O, [rn]() { rn->apply_preset(ResonatorNetwork::FormantPreset::VOWEL_O); });
    on_key_pressed(window, IO::Keys::U, [rn]() { rn->apply_preset(ResonatorNetwork::FormantPreset::VOWEL_U); });

    on_key_pressed(window, IO::Keys::N1, [rn, exciter]() {
        rn->clear_network_exciter();
        rn->set_exciter(exciter);
    });
    on_key_pressed(window, IO::Keys::N2, [rn, wv]() {
        rn->clear_exciter();
        rn->set_network_exciter(wv);
    });
    on_key_pressed(window, IO::Keys::N3, [rn, models]() {
        rn->clear_exciter();
        rn->set_network_exciter(models);
    });

    auto intensity_lfo = vega.Sine(0.1, 4) | Graphics;
    auto intensity_node = vega.Polynomial(
                              [intensity_lfo](double) {
                                  return 0.3 + intensity_lfo->get_last_output();
                              })
        | Graphics;
    auto count_node = vega.Constant(400.0) | Graphics;

    auto shader_config = Buffers::ShaderConfig { "hist_field.frag" };
    shader_config.push_constant_size = sizeof(PushParams);
    shader_config.bindings["history_data"] = Buffers::ShaderBinding(1, 1, vk::DescriptorType::eStorageBuffer);

    auto desc_bindings = std::make_shared<Buffers::DescriptorBindingsProcessor>(shader_config);
    desc_bindings->set_push_constant_size<PushParams>();
    desc_bindings->bind_network("history", rn, "history_data", 1);

    auto push_bindings = std::make_shared<Buffers::NodeBindingsProcessor>(shader_config);
    push_bindings->set_push_constant_size<PushParams>();
    push_bindings->bind_node("count", count_node, offsetof(PushParams, sample_count), sizeof(float));
    push_bindings->bind_node("intensity", intensity_node, offsetof(PushParams, intensity), sizeof(float));

    add_processor(desc_bindings, tex, Buffers::ProcessingToken::GRAPHICS_BACKEND);
    add_processor(push_bindings, tex, Buffers::ProcessingToken::GRAPHICS_BACKEND);
}

// =========================================================================
// PART 3: GPU GEOMETRY
// =========================================================================

// -------------------------------------------------------------------------
// I: Phasor Ring
// -------------------------------------------------------------------------
//
// 360 static vertices. The vertex shader repositions them in a ring
// pattern driven entirely by push constants: time, radius modulation,
// audio energy, aspect ratio. No CPU position updates.

void day3_i_phasor_ring()
{
    auto window = create_window({ .title = "Phasor Ring",
        .width = 1920,
        .height = 1080 });

    auto points = vega.PointCollectionNode(360) | Graphics;
    for (int i = 0; i < 360; ++i)
        points->add_point({ .position = glm::vec3(0.0F), .color = glm::vec3(1.0F), .size = 1.0F });

    auto geom = vega.GeometryBuffer(points) | Graphics;

    geom->setup_rendering({
        .target_window = window,
        .vertex_shader = "phasor_ring.vert.spv",
        .fragment_shader = "simple_passthrough.frag",
    });

    window->show();

    auto bell = vega.ModalNetwork(8, 440.0, ModalNetwork::Spectrum::INHARMONIC) | Audio[{ 0, 1 }];

    auto wobble = vega.Sine(0.2, 1.0);
    auto gate_state = std::make_shared<double>(0.0);
    auto gate = vega.Logic([gate_state](double x) {
        bool crossed = (*gate_state < 0.0) && (x >= 0.0);
        *gate_state = x;
        return crossed;
    });
    wobble >> gate;

    gate->on_change_to(true, [bell](auto&) {
        bell->excite(get_uniform_random(0.4, 0.85));
        bell->set_fundamental(get_uniform_random(300.0, 900.0));
    });

    struct Params {
        float time = 0.0F;
        float radius_mod = 0.0F;
        float energy = 0.0F;
        float aspect = 16.0F / 9.0F;
    };

    auto cached_energy = std::make_shared<std::atomic<float>>(0.0F);

    schedule_metro(0.016, [bell, cached_energy]() {
        float e = 0.0F;
        if (bell->get_audio_buffer().has_value())
            e = static_cast<float>(rms(bell->get_audio_buffer().value()) * 5.0);
        cached_energy->store(e, std::memory_order_relaxed);
    });

    auto time_node = vega.Phasor(0.02) | Graphics;
    auto radius_node = vega.Sine(0.3, 0.5) | Graphics;
    auto energy_node = vega.Polynomial(
                           [cached_energy](double) {
                               return static_cast<double>(cached_energy->load(std::memory_order_relaxed));
                           })
        | Graphics;
    auto aspect_node = vega.Constant(16.0 / 9.0) | Graphics;

    auto shader_config = Buffers::ShaderConfig { "phasor_ring.vert.spv" };
    shader_config.push_constant_size = sizeof(Params);

    auto node_bindings = std::make_shared<Buffers::NodeBindingsProcessor>(shader_config);
    node_bindings->set_push_constant_size<Params>();
    node_bindings->bind_node("time", time_node, offsetof(Params, time), sizeof(float));
    node_bindings->bind_node("radius", radius_node, offsetof(Params, radius_mod), sizeof(float));
    node_bindings->bind_node("energy", energy_node, offsetof(Params, energy), sizeof(float));
    node_bindings->bind_node("aspect", aspect_node, offsetof(Params, aspect), sizeof(float));

    add_processor(node_bindings, geom, Buffers::ProcessingToken::GRAPHICS_BACKEND);

    on_mouse_pressed(window, IO::MouseButtons::Left, [bell](double, double) {
        bell->excite(0.9);
    });
}

// -------------------------------------------------------------------------
// J: Wave Mesh
// -------------------------------------------------------------------------
//
// 80x80 grid of static vertices. The vertex shader displaces them with
// audio-driven sine wave fields. Video file provides background texture
// via a second render pass. Audio resonator's energy controls wave
// amplitude. Slow LFOs drift the wave frequencies.

void day3_j_wave_mesh()
{
    auto window = create_window({ .title = "Wave Mesh",
        .width = 1920,
        .height = 1080 });

    constexpr int GRID = 80;
    constexpr int VERTEX_COUNT = GRID * GRID;

    auto points = vega.PointCollectionNode(VERTEX_COUNT) | Graphics;
    for (int i = 0; i < VERTEX_COUNT; ++i) {
        int col = i % GRID;
        int row = i / GRID;
        float u = static_cast<float>(col) / static_cast<float>(GRID - 1) * 2.0F - 1.0F;
        float v = static_cast<float>(row) / static_cast<float>(GRID - 1) * 2.0F - 1.0F;
        float brightness = 0.4F + 0.6F * (static_cast<float>(row) / static_cast<float>(GRID));
        points->add_point({ .position = glm::vec3(u * 0.9F, v * 0.9F, 0.0F),
            .color = glm::vec3(0.2F, brightness, 1.0F),
            .size = 3.0F });
    }

    auto geom = vega.GeometryBuffer(points) | Graphics;

    geom->setup_rendering({
        .target_window = window,
        .vertex_shader = "wave_mesh.vert",
        .fragment_shader = "simple_passthrough.frag",
    });

    window->show();

    struct Params {
        float time = 0.0F;
        float freq_x = 5.0F;
        float freq_y = 4.0F;
        float amp_x = 0.5F;
        float amp_y = 0.5F;
        float grid_size = static_cast<float>(GRID);
    };

    auto noise = vega.Random() | Graphics;
    auto resonator = vega.Polynomial(
                         [noise](std::span<double> h) {
                             double impulse = 0.0;
                             if (std::abs(noise->get_last_output()) > 0.97) {
                                 impulse = noise->get_last_output() * 0.6;
                             }
                             return impulse + h[157] * 0.988;
                         },
                         PolynomialMode::RECURSIVE,
                         200)
        | Audio[{ 0, 1 }];
    resonator->set_initial_conditions({ 0.3, -0.1 });

    auto env = vega.Polynomial([](double x) { return std::abs(x); }) | Audio[0];
    env->enable_mock_process(true);
    env->set_input_node(resonator);

    auto time_node = vega.Phasor(0.03) | Graphics;

    auto freq_x_node = (vega.Constant(5.0) + vega.Sine(0.07, 3.0)) | Graphics;
    auto freq_y_node = (vega.Constant(4.0) + vega.Sine(0.05, 2.0)) | Graphics;

    auto amp_x_node = vega.Polynomial(
                          [env](double) { return 0.3 + env->get_last_output() * 2.0; })
        | Graphics;
    auto amp_y_node = vega.Polynomial(
                          [env](double) { return 0.2 + env->get_last_output() * 1.5; })
        | Graphics;
    auto grid_node = vega.Constant(static_cast<double>(GRID)) | Graphics;

    auto shader_config = Buffers::ShaderConfig { "wave_mesh.vert" };
    shader_config.push_constant_size = sizeof(Params);

    auto node_bindings = std::make_shared<Buffers::NodeBindingsProcessor>(shader_config);
    node_bindings->set_push_constant_size<Params>();
    node_bindings->bind_node("time", time_node, offsetof(Params, time), sizeof(float));
    node_bindings->bind_node("freq_x", freq_x_node, offsetof(Params, freq_x), sizeof(float));
    node_bindings->bind_node("freq_y", freq_y_node, offsetof(Params, freq_y), sizeof(float));
    node_bindings->bind_node("amp_x", amp_x_node, offsetof(Params, amp_x), sizeof(float));
    node_bindings->bind_node("amp_y", amp_y_node, offsetof(Params, amp_y), sizeof(float));
    node_bindings->bind_node("grid", grid_node, offsetof(Params, grid_size), sizeof(float));

    add_processor(node_bindings, geom, Buffers::ProcessingToken::GRAPHICS_BACKEND);
}

// -------------------------------------------------------------------------
// K: Orbit Cloud
// -------------------------------------------------------------------------
//
// 1000 vertices. The vertex shader assigns each vertex an elliptical
// orbit based on gl_VertexIndex. Time advances orbits. Audio energy
// contracts orbits (gravitational pulse), spectral centroid tilts the
// orbital plane, recursive delay network adds angular jitter.
// No CPU position updates. Pure GPU geometry generation.

void day3_k_orbit_cloud()
{
    auto window = create_window({ .title = "Orbit Cloud",
        .width = 1920,
        .height = 1080 });

    constexpr int ORBIT_COUNT = 1000;

    auto points = vega.PointCollectionNode(ORBIT_COUNT) | Graphics;
    for (int i = 0; i < ORBIT_COUNT; ++i) {
        float idx = static_cast<float>(i) / static_cast<float>(ORBIT_COUNT);
        points->add_point({ .position = glm::vec3(0.0F),
            .color = glm::vec3(0.6F + idx * 0.4F, 0.7F, 1.0F - idx * 0.3F),
            .size = 2.0F + idx * 3.0F });
    }

    auto geom = vega.GeometryBuffer(points) | Graphics;

    geom->setup_rendering({
        .target_window = window,
        .vertex_shader = "orbit_cloud.vert",
        .fragment_shader = "simple_passthrough.frag",
    });

    window->show();

    auto bell = vega.ModalNetwork(12, 300.0, ModalNetwork::Spectrum::INHARMONIC) | Audio[{ 0, 1 }];

    bell->set_coupling_enabled(true);
    bell->set_mode_coupling(0, 1, 0.1);
    bell->set_mode_coupling(1, 2, 0.1);

    auto trigger_lfo = vega.Sine(0.18, 1.0);
    auto trigger_state = std::make_shared<double>(0.0);
    auto trigger = vega.Logic([trigger_state](double x) {
        bool crossed = (*trigger_state < 0.0) && (x >= 0.0);
        *trigger_state = x;
        return crossed;
    });
    trigger_lfo >> trigger;

    trigger->on_change_to(true, [bell](auto&) {
        bell->excite_at_position(get_uniform_random(0.1, 0.9), get_uniform_random(0.3, 0.8));
        bell->set_fundamental(get_uniform_random(200.0, 600.0));
    });

    auto noise = vega.Random();
    auto jitter_net = vega.Polynomial(
                          [noise](std::span<double> h) {
                              double in = noise->get_last_output() * 0.02;
                              return in + h[73] * 0.45 + h[149] * 0.3 - h[293] * 0.15;
                          },
                          PolynomialMode::RECURSIVE,
                          300)
        | Graphics;
    jitter_net->set_initial_conditions({ 0.3, -0.2, 0.1 });

    struct Params {
        float time = 0.0F;
        float contraction = 0.0F;
        float tilt = 0.0F;
        float jitter = 0.0F;
        float aspect = 16.0F / 9.0F;
    };

    struct OrbitState {
        std::atomic<float> contraction { 0.0F };
        std::atomic<float> centroid_tilt { 0.0F };
    };
    auto orbit_state = std::make_shared<OrbitState>();

    schedule_metro(0.016, [bell, orbit_state]() {
        float e = 0.0F;
        if (bell->get_audio_buffer().has_value())
            e = static_cast<float>(rms(bell->get_audio_buffer().value()) * 4.0);
        orbit_state->contraction.store(e, std::memory_order_relaxed);

        const auto& modes = bell->get_modes();
        double weighted = 0.0;
        double total = 0.0;
        for (const auto& m : modes) {
            weighted += m.frequency_ratio * m.amplitude;
            total += m.amplitude;
        }
        orbit_state->centroid_tilt.store(
            static_cast<float>(total > 0.001 ? (weighted / total) * 0.3 : 0.0),
            std::memory_order_relaxed);
    });

    auto time_node = vega.Phasor(0.01) | Graphics;
    auto contraction_node = vega.Polynomial(
                                [orbit_state](double) {
                                    return static_cast<double>(orbit_state->contraction.load(std::memory_order_relaxed));
                                })
        | Graphics;
    auto centroid_node = vega.Polynomial(
                             [orbit_state](double) {
                                 return static_cast<double>(orbit_state->centroid_tilt.load(std::memory_order_relaxed));
                             })
        | Graphics;
    auto jitter_env = vega.Polynomial(
                          [jitter_net](double) {
                              return jitter_net->get_last_output() * 0.5;
                          })
        | Graphics;
    auto aspect_node = vega.Constant(16.0 / 9.0) | Graphics;

    auto shader_config = Buffers::ShaderConfig { "orbit_cloud.vert" };
    shader_config.push_constant_size = sizeof(Params);

    auto node_bindings = std::make_shared<Buffers::NodeBindingsProcessor>(shader_config);
    node_bindings->set_push_constant_size<Params>();
    node_bindings->bind_node("time", time_node, offsetof(Params, time), sizeof(float));
    node_bindings->bind_node("contraction", contraction_node, offsetof(Params, contraction), sizeof(float));
    node_bindings->bind_node("tilt", centroid_node, offsetof(Params, tilt), sizeof(float));
    node_bindings->bind_node("jitter", jitter_env, offsetof(Params, jitter), sizeof(float));
    node_bindings->bind_node("aspect", aspect_node, offsetof(Params, aspect), sizeof(float));

    add_processor(node_bindings, geom, Buffers::ProcessingToken::GRAPHICS_BACKEND);

    on_mouse_pressed(window, IO::MouseButtons::Left, [bell](double, double) {
        bell->excite(0.9);
        bell->set_fundamental(get_uniform_random(150.0, 800.0));
    });
}

// -------------------------------------------------------------------------
// L: IFS Tree
// -------------------------------------------------------------------------
//
// 2048 vertices positioned by an iterated function system in the vertex
// shader. Each vertex encodes a path through a binary tree (left/right
// branching at each depth level). Push constants control branch angle,
// scale factor, trunk bend, and audio energy. The tree breathes and
// sways with sound. Audio triggers grow/contract the canopy.

void day3_l_ifs_tree()
{
    auto window = create_window({ .title = "IFS Tree",
        .width = 1920,
        .height = 1080 });

    constexpr int IFS_POINTS = 2048;

    auto points = vega.PointCollectionNode(IFS_POINTS) | Graphics;
    for (int i = 0; i < IFS_POINTS; ++i) {
        float depth = static_cast<float>(i % 8) / 8.0F;
        points->add_point({ .position = glm::vec3(0.0F),
            .color = glm::vec3(0.3F + depth * 0.5F, 0.8F - depth * 0.3F, 0.2F + depth * 0.4F),
            .size = 6.0F - depth * 3.0F });
    }

    auto geom = vega.GeometryBuffer(points) | Graphics;

    geom->setup_rendering({
        .target_window = window,
        .vertex_shader = "ifs_tree.vert",
        .fragment_shader = "simple_passthrough.frag",
    });

    window->show();

    auto bell = vega.ModalNetwork(10, 180.0, ModalNetwork::Spectrum::INHARMONIC) | Audio[{ 0, 1 }];
    bell->set_coupling_enabled(true);
    bell->set_mode_coupling(0, 1, 0.12);
    bell->set_mode_coupling(1, 2, 0.08);

    auto slow_lfo = vega.Sine(0.1, 1.0);
    auto trig_state = std::make_shared<double>(0.0);
    auto trig = vega.Logic([trig_state](double x) {
        bool crossed = (*trig_state < 0.0) && (x >= 0.0);
        *trig_state = x;
        return crossed;
    });
    slow_lfo >> trig;

    trig->on_change_to(true, [bell](auto&) {
        bell->excite_at_position(get_uniform_random(0.2, 0.8), get_uniform_random(0.5, 0.9));
        bell->set_fundamental(get_uniform_random(100.0, 400.0));
    });

    struct Params {
        float time = 0.0F;
        float branch_angle = 0.4F;
        float branch_scale = 0.65F;
        float trunk_bend = 0.0F;
        float energy = 0.0F;
    };

    auto ifs_energy = std::make_shared<std::atomic<float>>(0.0F);

    schedule_metro(0.016, [bell, ifs_energy]() {
        float e = 0.0F;
        if (bell->get_audio_buffer().has_value())
            e = static_cast<float>(rms(bell->get_audio_buffer().value()) * 4.0);
        ifs_energy->store(e, std::memory_order_relaxed);
    });

    auto time_node = vega.Phasor(0.01) | Graphics;
    auto angle_node = (vega.Constant(0.4) + vega.Sine(0.06, 0.15)) | Graphics;
    auto scale_node = (vega.Constant(0.65) + vega.Sine(0.04, 0.08)) | Graphics;
    auto bend_node = vega.Sine(0.09, 0.15) | Graphics;
    auto energy_node = vega.Polynomial(
                           [ifs_energy](double) {
                               return static_cast<double>(ifs_energy->load(std::memory_order_relaxed));
                           })
        | Graphics;

    auto shader_config = Buffers::ShaderConfig { "ifs_tree.vert" };
    shader_config.push_constant_size = sizeof(Params);

    auto node_bindings = std::make_shared<Buffers::NodeBindingsProcessor>(shader_config);
    node_bindings->set_push_constant_size<Params>();
    node_bindings->bind_node("time", time_node, offsetof(Params, time), sizeof(float));
    node_bindings->bind_node("angle", angle_node, offsetof(Params, branch_angle), sizeof(float));
    node_bindings->bind_node("scale", scale_node, offsetof(Params, branch_scale), sizeof(float));
    node_bindings->bind_node("bend", bend_node, offsetof(Params, trunk_bend), sizeof(float));
    node_bindings->bind_node("energy", energy_node, offsetof(Params, energy), sizeof(float));

    add_processor(node_bindings, geom, Buffers::ProcessingToken::GRAPHICS_BACKEND);

    on_mouse_pressed(window, IO::MouseButtons::Left, [bell](double, double) {
        bell->excite(0.9);
    });

    on_key_pressed(window, IO::Keys::Space, [bell]() {
        bell->set_fundamental(get_uniform_random(80.0, 500.0));
        bell->excite_at_position(get_uniform_random(0.1, 0.9), 0.95);
    });
}
