#pragma once

#define MAYASIMPLE
#include "MayaFlux/MayaFlux.hpp"

/// @brief A single struck bell. Periodic sine trigger. Visual spiral grows on strike.
void day1_a_first_bell();

/// @brief Plucked string. Brownian walk decides when to pluck. Points appear at strike position.
void day1_b_wandering_string();

/// @brief Resonant vowel body fed by noise. Sequential logic breaks regularity. Burst visuals.
void day1_c_breathing_vowel();

/// @brief Two bodies (string + bell), alternating. Stochastic timing via exponential distribution.
void day1_d_two_bodies();

/// @brief Full interactive system. Three rhythm sources, three visual modes, mouse excitation.
void day1_e_playground();
