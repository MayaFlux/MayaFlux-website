#include "wt1.hpp"

// =========================================================================
// A: First Bell
// =========================================================================
//
// The simplest audiovisual system. A modal bell struck by a periodic trigger.
// One resonant body. One oscillator deciding timing. One visual field reacting.
//
// Run it. Listen. Watch the spiral grow. Then read on.

void day1_a_first_bell()
{
    auto bell = vega.ModalNetwork(
                    12, 220.0,
                    ModalNetwork::Spectrum::INHARMONIC)
        | Audio[{ 0, 1 }];

    auto trigger_osc = vega.Sine(0.3, 1.0);

    auto swing = vega.Logic(LogicOperator::THRESHOLD, 0.85);
    trigger_osc >> swing;

    swing->on_change_to(false, [bell](auto&) {
        bell->excite(get_uniform_random(0.5F, 0.9F));
        bell->set_fundamental(get_uniform_random(220.0F, 800.0F));
    });

    auto window = MayaFlux::create_window({ .title = "First Bell",
        .width = 1280,
        .height = 720 });

    auto points = vega.PointCollectionNode(500) | Graphics;
    auto geom = vega.GeometryBuffer(points) | Graphics;
    geom->setup_rendering({ .target_window = window });
    window->show();

    struct Spiral {
        float angle = 0.0F;
        float radius = 0.0F;
    };
    auto spiral = std::make_shared<Spiral>();

    schedule_metro(0.016, [points, bell, spiral]() {
        float energy = bell->get_audio_buffer().has_value()
            ? static_cast<float>(rms(bell->get_audio_buffer().value())) * 5.0F
            : 0.0F;

        if (energy > 0.05F) {
            spiral->angle += 0.5F + energy * 0.3F;
            spiral->radius += 0.002F;
        } else {
            spiral->angle += 0.01F;
            spiral->radius += 0.0001F;
        }

        if (spiral->radius > 1.0F) {
            spiral->radius = 0.0F;
            points->clear_points();
        }

        float x = std::cos(spiral->angle) * spiral->radius;
        float y = std::sin(spiral->angle) * spiral->radius * (16.0F / 9.0F);
        float brightness = 1.0F - spiral->radius * 0.7F;

        points->add_point({ .position = glm::vec3(x, y, 0.0F),
            .color = glm::vec3(brightness, brightness * 0.8F, 1.0F),
            .size = 8.0F + spiral->radius * 4.0F });
    });
}

// =========================================================================
// B: Wandering String
// =========================================================================
//
// A plucked string instead of a struck bell. The timing source is no longer
// a periodic sine: a Brownian random walk decides when to pluck.
// The pluck position is randomized, so timbre shifts with each event.
// Visuals: each pluck spawns a cluster of points at the pluck position.

void day1_b_wandering_string()
{
    auto string = vega.WaveguideNetwork(
                      WaveguideNetwork::WaveguideType::STRING,
                      196.0)
        | Audio[{ 0, 1 }];

    auto walker = vega.Random(Kinesis::Stochastic::Algorithm::BROWNIAN);

    struct State {
        double last_walker = 0.0;
        float pluck_x = 0.0F;
    };
    auto state = std::make_shared<State>();

    auto gate = vega.Logic([state](double input) {
        bool crossed = (state->last_walker < 0.3) && (input >= 0.3);
        state->last_walker = input;
        return crossed;
    });
    walker >> gate;

    gate->on_change_to(true, [string, state](auto&) {
        double pos = get_uniform_random(0.1, 0.9);
        state->pluck_x = static_cast<float>(pos) * 2.0F - 1.0F;
        string->pluck(pos, get_uniform_random(0.4, 0.85));
        string->set_fundamental(get_uniform_random(98.0, 440.0));
    });

    auto window = MayaFlux::create_window({ .title = "Wandering String",
        .width = 1280,
        .height = 720 });

    auto points = vega.PointCollectionNode(1000) | Graphics;
    auto geom = vega.GeometryBuffer(points) | Graphics;
    geom->setup_rendering({ .target_window = window });
    window->show();

    schedule_metro(0.016, [points, string, state]() {
        float energy = string->get_audio_buffer().has_value()
            ? static_cast<float>(rms(string->get_audio_buffer().value())) * 5.0F
            : 0.0F;

        if (energy > 0.15F) {
            int burst = static_cast<int>(energy * 40);
            for (int i = 0; i < burst; ++i) {
                auto a = static_cast<float>(get_uniform_random(0.0, 6.28));
                auto r = static_cast<float>(get_uniform_random(0.01, 0.08));

                points->add_point({ .position = glm::vec3(
                                        state->pluck_x + std::cos(a) * r,
                                        std::sin(a) * r,
                                        0.0F),
                    .color = glm::vec3(
                        energy * 2.0F,
                        0.6F - energy * 0.3F,
                        0.9F),
                    .size = static_cast<float>(get_uniform_random(3.0, 12.0)) });
            }
        }

        if (points->get_point_count() > 1000) {
            points->clear_points();
        }
    });

    on_mouse_pressed(window, IO::MouseButtons::Left, [window, string](double x, double y) {
        glm::vec2 pos = normalize_coords(x, y, window);
        double pluck_pos = (static_cast<double>(pos.x) + 1.0) * 0.5;
        double strength = std::clamp(1.0 - static_cast<double>(pos.y), 0.3, 0.9);
        string->pluck(pluck_pos, strength);
    });
}

// =========================================================================
// C: Breathing Vowel
// =========================================================================
//
// Not a pluck or strike: a continuous excitation through a resonant body.
// ResonatorNetwork shapes noise into vowel formants.
// Timing: sequential logic watches a history of 4 threshold crossings.
// The trigger fires only when exactly 3 of the last 4 were true,
// creating an irregular, breathing rhythm that cannot be periodic.

void day1_c_breathing_vowel()
{
    auto vowel = vega.ResonatorNetwork(
                     5, ResonatorNetwork::FormantPreset::VOWEL_A)
        | Audio[{ 0, 1 }];

    auto noise = vega.Random();
    vowel->set_exciter(noise);

    auto drift = vega.Sine(0.07, 1.0);

    auto breath = vega.Logic();
    breath->set_sequential_function(
        [](std::span<bool> history) {
            int count = 0;
            for (bool b : history) {
                if (b)
                    ++count;
            }
            return count == 3;
        },
        4);
    drift >> breath;

    struct State {
        float hue_phase = 0.0F;
    };
    auto state = std::make_shared<State>();

    breath->on_change_to(true, [vowel, state](auto&) {
        vowel->set_frequency(0, get_uniform_random(600.0, 900.0));
        vowel->set_frequency(1, get_uniform_random(1000.0, 1400.0));
        vowel->set_frequency(2, get_uniform_random(2200.0, 2800.0));
        vowel->set_q(0, get_uniform_random(8.0, 25.0));
        state->hue_phase += 0.75F;
    });

    auto window = MayaFlux::create_window({ .title = "Breathing Vowel",
        .width = 1280,
        .height = 720 });

    auto points = vega.PointCollectionNode(800) | Graphics;
    auto geom = vega.GeometryBuffer(points) | Graphics;
    geom->setup_rendering({ .target_window = window });
    window->show();

    schedule_metro(0.016, [points, vowel, state]() {
        float energy = vowel->get_audio_buffer().has_value()
            ? static_cast<float>(rms(vowel->get_audio_buffer().value())) * 8.0F
            : 0.0F;

        int density = static_cast<int>(energy * 30);
        for (int i = 0; i < density; ++i) {
            float spread = energy * 4.6F;
            float x = static_cast<float>(get_uniform_random(-spread, spread));
            float y = static_cast<float>(get_uniform_random(-spread, spread));

            float h = state->hue_phase + static_cast<float>(i) * 0.01F;
            points->add_point({ .position = glm::vec3(x, y, 0.0F),
                .color = glm::vec3(
                    std::sin(h) * 0.5F + 0.5F,
                    std::sin(h + 2.09F) * 0.5F + 0.5F,
                    std::sin(h + 4.19F) * 0.5F + 0.5F),
                .size = 4.0F + energy * 8.0F });
        }

        if (points->get_point_count() > 800) {
            points->clear_points();
        }
    });

    on_key_pressed(window, IO::Keys::N1, [vowel]() {
        vowel->apply_preset(ResonatorNetwork::FormantPreset::VOWEL_A);
    });
    on_key_pressed(window, IO::Keys::N2, [vowel]() {
        vowel->apply_preset(ResonatorNetwork::FormantPreset::VOWEL_E);
    });
    on_key_pressed(window, IO::Keys::N3, [vowel]() {
        vowel->apply_preset(ResonatorNetwork::FormantPreset::VOWEL_I);
    });
    on_key_pressed(window, IO::Keys::N4, [vowel]() {
        vowel->apply_preset(ResonatorNetwork::FormantPreset::VOWEL_O);
    });
    on_key_pressed(window, IO::Keys::N5, [vowel]() {
        vowel->apply_preset(ResonatorNetwork::FormantPreset::VOWEL_U);
    });
}

// =========================================================================
// D: Two Bodies
// =========================================================================
//
// A string and a bell occupy the same space. They alternate excitation.
// Timing: exponential random distribution produces clustered, irregular events
// (many quick strikes followed by long silences). Fundamentally different
// from sine-based periodic triggers.
// The visual field shows both bodies: string bursts on the left, bell
// spirals on the right. Energy from one subtly shifts the other's color.

void day1_d_two_bodies()
{
    auto string = vega.WaveguideNetwork(
                      WaveguideNetwork::WaveguideType::STRING,
                      147.0)
        | Audio[0];

    auto bell = vega.ModalNetwork(
                    8, 440.0,
                    ModalNetwork::Spectrum::INHARMONIC)
        | Audio[1];

    bell->set_coupling_enabled(true);
    bell->set_mode_coupling(0, 1, 0.12);
    bell->set_mode_coupling(1, 2, 0.08);
    bell->set_output_scale(0.26);

    auto expo_random = vega.Random(Kinesis::Stochastic::Algorithm::EXPONENTIAL);

    struct State {
        double last_val = 0.0;
        bool string_turn = true;
        float bell_angle = 0.0F;
        float bell_radius = 0.0F;
    };
    auto state = std::make_shared<State>();

    auto trigger = vega.Logic([state](double input) {
        bool spike = (state->last_val < 0.7) && (input >= 0.7);
        state->last_val = input;
        return spike;
    });
    // expo_random >> trigger;
    trigger->set_input_node(expo_random);

    trigger->on_change_to(true, [string, bell, state](auto&) {
        if (state->string_turn) {
            double pos = get_uniform_random(0.15, 0.85);
            string->pluck(pos, get_uniform_random(0.4, 0.8));
            string->set_fundamental(get_uniform_random(98.0, 330.0));
        } else {
            bell->excite(get_uniform_random(0.4, 0.85));
            bell->set_fundamental(get_uniform_random(330.0, 1200.0));
        }
        state->string_turn = !state->string_turn;
    });

    auto window = MayaFlux::create_window({ .title = "Two Bodies",
        .width = 1920,
        .height = 1080 });

    auto points = vega.PointCollectionNode(1500) | Graphics;
    auto geom = vega.GeometryBuffer(points) | Graphics;
    geom->setup_rendering({ .target_window = window });
    window->show();

    schedule_metro(1, [expo_random, trigger]() {
        expo_random->process_sample();
        trigger->process_sample();
    });

    schedule_metro(0.016, [points, string, bell, state]() {
        float str_energy = string->get_audio_buffer().has_value()
            ? static_cast<float>(rms(string->get_audio_buffer().value())) * 5.0F
            : 0.0F;

        float bell_energy = bell->get_audio_buffer().has_value()
            ? static_cast<float>(rms(bell->get_audio_buffer().value())) * 5.0F
            : 0.0F;

        if (str_energy > 0.1F) {
            int burst = static_cast<int>(str_energy * 30);
            for (int i = 0; i < burst; ++i) {
                auto a = static_cast<float>(get_uniform_random(0.0, 6.28));
                auto r = static_cast<float>(get_uniform_random(0.01, 0.15));
                points->add_point({ .position = glm::vec3(
                                        -0.45F + std::cos(a) * r,
                                        std::sin(a) * r,
                                        0.0F),
                    .color = glm::vec3(
                        1.0F,
                        0.4F + bell_energy * 0.5F,
                        0.2F + bell_energy * 0.3F),
                    .size = static_cast<float>(get_uniform_random(4.0, 14.0)) });
            }
        }

        if (bell_energy > 0.05F) {
            state->bell_angle += 0.4F + bell_energy * 0.5F;
            state->bell_radius += 0.0015F;
        } else {
            state->bell_angle += 0.005F;
            state->bell_radius += 0.0001F;
        }

        if (state->bell_radius > 0.5F) {
            state->bell_radius = 0.0F;
        }

        float bx = 0.45F + std::cos(state->bell_angle) * state->bell_radius;
        float by = std::sin(state->bell_angle) * state->bell_radius;

        points->add_point({ .position = glm::vec3(bx, by, 0.0F),
            .color = glm::vec3(
                0.3F + str_energy * 0.4F,
                0.4F,
                1.0F),
            .size = 6.0F + bell_energy * 10.0F });

        if (points->get_point_count() > 1500) {
            points->clear_points();
        }
    });

    on_mouse_pressed(window, IO::MouseButtons::Left, [window, string, bell](double x, double y) {
        glm::vec2 pos = normalize_coords(x, y, window);
        if (pos.x < 0.0F) {
            string->pluck((static_cast<double>(pos.x) + 1.0) * 0.5, 0.8);
        } else {
            bell->excite_at_position(
                (static_cast<double>(pos.x)) * 0.5,
                std::clamp(1.0 - static_cast<double>(pos.y), 0.3, 0.9));
        }
    });
}

// =========================================================================
// E: Playground
// =========================================================================
//
// Everything combined. A coupled modal bell with pitch drift, three
// switchable rhythm sources (slow sine, fast sine, exponential random),
// three visual modes (spiral, burst, field), mouse strike control.
// This is the full interactive system that participants explore freely.

void day1_e_playground()
{
    auto window = create_window({ .title = "Playground", .width = 1920, .height = 1080 });
    window->show();

    auto bell = vega.ModalNetwork(12, 220.0, ModalNetwork::Spectrum::INHARMONIC);

    bell->set_coupling_enabled(true);
    bell->set_mode_coupling(0, 1, 0.15);
    bell->set_mode_coupling(1, 2, 0.15);
    bell->set_mode_coupling(2, 3, 0.08);
    bell->set_mode_coupling(3, 4, 0.08);

    auto pitch_drift = vega.Sine(0.05, 80.0) | Audio[0];
    pitch_drift->enable_mock_process(true);
    bell->map_parameter("frequency", pitch_drift, MappingMode::BROADCAST);

    auto slow_rhythm = vega.Sine(0.2, 1.0);
    auto fast_rhythm = vega.Sine(2.0, 1.0);
    auto erratic = vega.Random(Kinesis::Stochastic::Algorithm::EXPONENTIAL);

    struct State {
        int visual_mode = 0;
        int rhythm_mode = 0;
        uint32_t side = 0;
        float angle = 0.0F;
        float radius = 0.0F;
        double last_input = 0.0;
    };
    auto state = std::make_shared<State>();

    auto swing = vega.Logic([state](double input) {
        bool crossed = (state->last_input < 0.0) && (input >= 0.0);
        state->last_input = input;
        return crossed;
    });
    slow_rhythm >> swing;

    swing->on_change_to(false, [bell, state](auto&) {
        bell->excite_at_position(get_uniform_random(0.1, 0.9), get_uniform_random(0.5, 0.9));
        bell->set_fundamental(get_uniform_random(200.0, 800.0));
        route_network(bell, { state->side }, 0.15);
        state->side = 1 - state->side;
    });

    auto points = vega.PointCollectionNode(2000) | Graphics;
    auto geom = vega.GeometryBuffer(points) | Graphics;
    geom->setup_rendering({ .target_window = window });

    schedule_metro(0.016, [points, bell, pitch_drift, state]() {
        float energy = 0.F;
        if (bell->get_audio_buffer().has_value()) {
            energy = static_cast<float>(rms(bell->get_audio_buffer().value())) * 5.0F;
        }

        float drift_val = static_cast<float>(pitch_drift->get_last_output()) / 160.0F;
        float hue = drift_val + 0.5F;

        if (state->visual_mode == 0) {
            if (energy > 0.05F) {
                state->angle += 0.5F + drift_val * 0.8F;
                state->radius += 0.002F;
            } else {
                state->angle += 0.01F;
                state->radius += 0.0001F;
            }
            if (state->radius > 1.0F) {
                state->radius = 0.0F;
                points->clear_points();
            }
            points->add_point({ .position = glm::vec3(
                                    std::cos(state->angle) * state->radius,
                                    std::sin(state->angle) * state->radius * (16.0F / 9.0F),
                                    0.0F),
                .color = glm::vec3(hue, 0.8F, 1.0F - hue),
                .size = 8.0F + state->radius * 4.0F + energy * 10.0F });

        } else if (state->visual_mode == 1) {
            if (energy > 0.3F) {
                for (int i = 0; i < 20; ++i) {
                    auto a = static_cast<float>(get_uniform_random(0.0, 6.28));
                    auto r = static_cast<float>(get_uniform_random(0.01, 0.08));
                    points->add_point({ .position = glm::vec3(
                                            drift_val + std::cos(a) * r,
                                            std::sin(a) * r, 0.0F),
                        .color = glm::vec3(
                            hue,
                            static_cast<float>(get_uniform_random(0.5, 1.0)),
                            0.3F),
                        .size = static_cast<float>(get_uniform_random(5.0, 15.0)) });
                }
            }
            if (points->get_point_count() > 2000) {
                points->clear_points();
            }

        } else {
            int density = static_cast<int>(energy * 60);
            for (int i = 0; i < density; ++i) {
                float x = drift_val + static_cast<float>(get_uniform_random(-0.6, 0.6));
                float y = static_cast<float>(get_uniform_random(-0.8, 0.8));
                points->add_point({ .position = glm::vec3(x, y, 0.0F),
                    .color = glm::vec3(energy, 0.5F, 1.0F - energy),
                    .size = 3.0F + energy * 5.0F });
            }
            if (points->get_point_count() > 2000) {
                points->clear_points();
            }
        }
    });

    on_mouse_pressed(window, IO::MouseButtons::Left, [window, bell](double x, double y) {
        glm::vec2 pos = normalize_coords(x, y, window);
        double strike_pos = (static_cast<double>(pos.x) + 1.0) * 0.5;
        double strike_strength = std::clamp(1.0 - static_cast<double>(pos.y), 0.3, 0.9);
        bell->excite_at_position(strike_pos, strike_strength);
    });

    on_key_pressed(window, IO::Keys::N1, [points, state]() {
        state->visual_mode = 0;
        points->clear_points();
    });
    on_key_pressed(window, IO::Keys::N2, [points, state]() {
        state->visual_mode = 1;
        points->clear_points();
    });
    on_key_pressed(window, IO::Keys::N3, [points, state]() {
        state->visual_mode = 2;
        points->clear_points();
    });

    on_key_pressed(window, IO::Keys::Space, [swing, slow_rhythm, fast_rhythm, erratic, state]() {
        state->rhythm_mode = (state->rhythm_mode + 1) % 3;
        if (state->rhythm_mode == 0) {
            swing->set_input_node(slow_rhythm);
        } else if (state->rhythm_mode == 1) {
            swing->set_input_node(fast_rhythm);
        } else {
            swing->set_input_node(erratic);
        }
    });

    on_key_pressed(window, IO::Keys::M, [bell]() {
        route_network(bell, { 0, 1 }, 0.3);
    });
    on_key_pressed(window, IO::Keys::S, [bell]() {
        route_network(bell, { 0 }, 0.3);
    });
}
